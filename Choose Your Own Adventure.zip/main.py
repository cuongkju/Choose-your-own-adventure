'''
Choose Your Own Adventure Project
This program lets you choose your own direction and ending of a story. Different choices will leadyou to different endings whether it's good or bad
Created by: Richard Cao
Created on: 04/04/2022
Last modified: 04/15/2022 

'''
import random,sys,time

#Program to make the text appears slowly
def slow (string):
    for i in string:
        print (i, end = "")
        if slow_Value:
            sys.stdout.flush()
            time.sleep (0.003)

#Set True for the text to appear slowly, False to not. 
slow_Value = True

#Pokemon dictionary
gengar = {"name":"Gengar", "defence": 30, "hp": 100}
dragonite = {"name":"Dragonite", "defence": 10, "hp": 90}
arcanine = {"name":"Arcanine", "defence": 40, "hp": 110}
zapdos = {"name":"Zapdos", "defence": 30, "hp": 80}
mewtwo = {"name":"Mewtwo","attack": 10, "defence": 0, "hp": 200}

good_ending = ('''The day of the quiz, you come to school prepared. A few days later, your teacher gives back the quiz and the result does not surprise and dissapoint you.
You score an 90%. With that confidence, you end the semester at one of the top spots of your class.

CONGRATULATION! You got the good ending of the story.''')

bad_ending = ('''Your routine of not doing your homework has led to the result of you failing the quiz. That is the 3rd test/quiz you've failed in the course of 2 weeks.
Discouraged by the fact that your mark won't be better, you fail the course and end up at the bottom of the class.

You've unlocked the sad/bad ending of the story. :( ''')

boring_ending = ('''You've plenty of time studying for the next quiz. You start creating study notes and stategy to study for your quiz/test and make that into a routine.
Not only this routine helps you with math, but with every subject. You graduated with one of the highest average of your school. You know for a fact that you will do great in college

You've unlocked the most boring ending out of the four.''')

#Story title
print ('''     _      _   _                            _      _     __ _                                    
    / \    | \ | | ___  _ __ _ __ ___   __ _| |    / \   / _| |_ ___ _ __ _ __   ___   ___  _ __  
   / _ \   |  \| |/ _ \| '__| '_ ` _ \ / _` | |   / _ \ | |_| __/ _ \ '__| '_ \ / _ \ / _ \| '_ \ 
  / ___ \  | |\  | (_) | |  | | | | | | (_| | |  / ___ \|  _| ||  __/ |  | | | | (_) | (_) | | | |
 /_/   \_\ |_| \_|\___/|_|  |_| |_| |_|\__,_|_| /_/   \_\_|  \__\___|_|  |_| |_|\___/ \___/|_| |_|
                                                                                                  ''')

slow ('''You had a bad day at school today after failing your second math test in a row. 
Because of this failed test, your math average is now 45% and you could fail Grade 12 Advanced Functions. 
You come back home from school that afternoon   
''')
print ()
slow('''What should be the first thing that you do when you come home:
A: You grab a snack since you're hungry after a long day
B: You go straight to play your favourite video games
C: You go do your math homework and be prepared for the next quiz
''')
print ()
question = input("What is your choice: ")

#If the user choose a in question
if question.lower() == "a":
    print ()
    
    slow ('''Great choice, now you have the energy to do the next thing. Suddenly, your mom asks you to clean the house, that includes your room, the washroom and the kitchen. That's a lot of tasks to do in one afternoon. You have three choices:
A: Take your time cleaning the house while listening to music
B: Clean the house as fast as possible
C: Ignore your mom and not clean the house
''')
    print()
    choiceA = input("What is your choice? ")
    total_time = 0
    #If the user choose a, the total time will be more than 60
    if choiceA.lower() == "a":
        for i in range (3):
            total_time += random.randint(20,30)
        print ()
        slow (("The total time you spent cleaning the house is ", total_time," minutes!"))
    #Less than 60 if choose b
    elif choiceA.lower() == "b":
        for i in range (3):
            total_time += random.randint(10,15)
        print ()
        slow (("The total time you spent cleaning the house is ", total_time," minutes!"))
    #If the user choose c in choiceA, it leads to another question
    elif choiceA.lower() == "c": 
        print ()
        slow ('''Later that night, you have dinner with your parents. Your parents ask how you're doing at school and you lie to them. While you're watching the TV after dinner, your mom comes into your room.
Not only did she see your room not being cleaned up, she also see your test's mark. You're grounded for the next two week.''')
        choiceAC = input ('''
What would you do?

A: Spend the next two weeks focusing on school
B: Ask your mom for permission to use your phone and laptop for school purposes
C: Still go out with your friends even though you're grounded

What's your choice? ''')

        
        if choiceAC.lower() == "a" or choiceAC.lower() == "b":
            print ()
            slow (good_ending)
        elif choiceAC.lower() == "c": 
            print ()
            slow (bad_ending) 
    
    #Basically the user choose a in choiceA
    if total_time != 0 and total_time < 60:
        print ()
        slow ('''
Knowing that you will have to spend some time tonight studying, you quickly finish all your chores, just in time for dinner. You had dinner with your parent and go back to your room.''')
        print ()
        slow (boring_ending)

    #The user choose b in choiceA
    elif total_time != 0 and total_time >= 60:
        slow ('''You spend more than an hour to do your chores! That certainly will leave you with less time to do your homework and study for the quiz that is two days from now. 
Knowing that you should've done your chores quicker, you quickly finish your dinner and go back to your room to do homeworks. ''')
        lazy = input('''
You have two choices:

A: Do a varity of different questions and focus on units that you think are mostly likely will be on the quiz
B: Do as many questions as possible without a strategy

What's your choice? ''')
        if lazy.lower() == "a":
            slow (good_ending)
        elif lazy.lower() == "b":
            slow ('''Doing a lot of homework questions is great, but studying without a strategy might not be enough to prepare you for bigger tests and exams.
You end the semester with a 75% in Advanced Functions. It is definitely the mark that you were hoping for but let's look at it from the bright side, you were on the verge of failing.

Don't be discouraged, you will do great next year !!!''')

#The user choose c in question
elif question.lower() == "c" :
    slow (boring_ending)

#The user choose b in question
elif question.lower() == "b":
    slow ('''You had a disappointing school day so you decided to go straight to your room to play your favourite video games 'Pokemon showdown'. 
You have four choices for your for the battle with Mewtwo: 

A: Gengar  
B: Dragonite
C: Arcanine
D: Zapdos ''')
    print()
    choiceC = input("What's your choice? ") 

    if choiceC.lower() == "a":
        pokemon = gengar
        slow (("Your pokemon is ", pokemon["name"],";", " Your pokemon's hp is ", pokemon["hp"],"; ","Your pokemon's defence is ",pokemon["defence"]))
        print()
        slow (("Mewtwo's hp is ",mewtwo["hp"],"; ","Mewtwo's defence is ",mewtwo["defence"]))
        print()
    elif choiceC.lower() == "b":
        pokemon = dragonite
        slow (("Your pokemon is ", pokemon["name"],";"," Your pokemon's hp is ", pokemon["hp"],"; ","Your pokemon's defence is ",pokemon["defence"]))
        print()
        slow (("Mewtwo's hp is ",mewtwo["hp"],"; ","Mewtwo's defence is ",mewtwo["defence"]))
        print()
    elif choiceC.lower() == "c":
        pokemon = arcanine
        slow (("Your pokemon is ", pokemon["name"],";", " Your pokemon's hp is ", pokemon["hp"],"; ","Your pokemon's defence is ",pokemon["defence"]))
        print()
        slow (("Mewtwo's hp is ",mewtwo["hp"],"; ","Mewtwo's defence is ",mewtwo["defence"]))
        print()
    elif choiceC.lower() == "d":
        pokemon = zapdos
        slow (("Your pokemon is ", pokemon["name"],";", " Your pokemon's hp is ", pokemon["hp"],"; ","Your pokemon's defence is ",pokemon["defence"]))
        print()
        slow (("Mewtwo's hp is ",mewtwo["hp"],"; ","Mewtwo's defence is ",mewtwo["defence"]))
        print()
    print ()
    slow ("Your battle with Mewtwo has started!")

#The video game in option b
    i = 1
    countc = 0
    while i > 0: 
            
        move = input ('''
You have three options every round:
    A: Attack 
    B: Defence
    C: Dodge
    Make your choice: ''')
        
        if move.lower() == "a":
            dam = random.randint(10,20)
            mewtwo["hp"] = mewtwo["hp"] - dam
            print ()
            print ("You've hit Mewtwo ", dam)
            if pokemon["defence"] > 0:
                pokemon["defence"] = pokemon["defence"] - mewtwo["attack"]
            elif pokemon["defence"] <= 0:
                pokemon["defence"] = 0
                pokemon["hp"] = pokemon["hp"] - mewtwo["attack"]
            print()
            slow (("Your pokemon's hp is ", pokemon["hp"],"; ","Your pokemon's defence is ",pokemon["defence"]))
            print()
            slow (("Mewtwo's hp is ",mewtwo["hp"],"; ","Mewtwo's defence is ",mewtwo["defence"]))
            print()
        elif move.lower() == "b":
            pokemon["defence"] = pokemon["defence"] - 0.5*mewtwo["attack"]
            if pokemon["defence"] <= 0:
                pokemon["defence"] = 0
                pokemon["hp"] = pokemon["hp"] - 0.5*mewtwo["attack"]
                print ()
                slow (("Your pokemon's hp is ", pokemon["hp"],";"," Your pokemon's defence is ",pokemon["defence"]))
                print()
                slow (("Mewtwo's hp is ",mewtwo["hp"],";"," Mewtwo's defence is ", mewtwo["defence"]))
                print()
        elif move.lower() == "c":
                continue
                 
        if pokemon["hp"] <= 0 or mewtwo["hp"] <= 0:
            i -= 1   
        if pokemon["hp"] <= 0 and mewtwo["hp"] > 0:
            print ("DEFEAT! Mewtwo is too strong for your pokemon. Better luck next time!")
        elif pokemon["hp"] > 0 and mewtwo["hp"] <= 0:
            print ("VICTORY! Your pokemon reigns supreme over the powerful Mewtwo")
#If your pokemon and mewtwo both end up with 0 or below in hp, this secret ending will pop up
        elif pokemon["hp"] <= 0 and mewtwo["hp"] <= 0:
            slow ('''Congratulation !!!. You have unlocked an easter egg. Your version of Pokemon Showdown is one of few that has this easter egg! 
This can only be achieved when your pokemon and mewtwo die at the same time. Here is a secret code "HZX8B9J". Input this code using this link: https://www.pokemonshowdown.com/ca to receive your prize''')

    print (''' 
            ____                         ___                 
           / ___| __ _ _ __ ___   ___   / _ \__   _____ _ __ 
          | |  _ / _` | '_ ` _ \ / _ \ | | | \ \ / / _ \ '__|
          | |_| | (_| | | | | | |  __/ | |_| |\ V /  __/ |   
           \____|\__,_|_| |_| |_|\___|  \___/  \_/ \___|_|   
                                                            ''')        
    print ()
    if pokemon["hp"] <= 0 and mewtwo["hp"] <= 0:
        slow ('''You just received the code to a mystery prize. You follow the instruction and input the code. The website reveals that you just won a trip to Japan and visit the game studio that made your favourite game. ''')
        easter_quest = input('''
You can:
A: Go to Japan with your friends in the summer.
B: Sell the code for money 

What's you choice? ''')
        if easter_quest.lower() == "a":
            print ()
            slow ('''Your parent say that they only allow you to go to the trip if you earn at least an 80%. Since you want to go to this trip so hard, you work really hard and earn the mark.
You go to Japan with your friends that summer and have fond memories with them :)

CONGRATULATION! You've unlocked one of the two special ending! ''')

        elif easter_quest.lower() == "b":
            print ()
            slow ('''Since this code is worth a trip to Japan, you sell it for a fairly price. You decide to save the money for college.
            
CONGRATULATION! You've unlocked one of the two special ending! ''')

# If your pokemon beat or lose to mewtwo, these endings will happen 
    else:
        slow ('''WAKE UP! WAKE UP! Your mom wakes you up. Suddenly you realize that you passed out for the last 4 hours because you were too tired! Your tummy is growling, telling you that it needs foods.
Looking at the clock, it's 9:30 PM already.''')
        noneaster_quest = input('''
You can:

A: Go eat some food and go back to sleep 
B: Go get some food and do your homework because the next quiz is 2 days from now 

What's your choice? ''')

        if noneaster_quest.lower() != "a":
            print ()
            slow (good_ending)
        
        else:
            print ()
            slow (bad_ending)
